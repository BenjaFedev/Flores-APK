# Flores para mi niña

App Android sin conexión. Abre el sobre, toca la carta para guardarla y planta flores amarillas al tocar o deslizar. El botón inferior permite volver a leerla.

Para compilar, abre esta carpeta en Android Studio, acepta la sincronización de Gradle y selecciona Build > Build Bundle(s) / APK(s) > Build APK(s). El APK aparecerá en app/build/outputs/apk/debug/app-debug.apk.

Puedes probar index.html directamente en un navegador moderno.

## Sin Android Studio

Sube el CONTENIDO de esta carpeta a la raíz de un repositorio GitHub (incluida la carpeta oculta .github). En la pestaña Actions, ejecuta «Compilar APK» desde «Run workflow». Descarga el artefacto «Flores-para-mi-nina-APK», descomprime el ZIP descargado y envía app-debug.apk. Necesitarás iniciar sesión en GitHub; no hay que instalar Android Studio.
